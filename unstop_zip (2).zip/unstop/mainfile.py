import os
import fitz  # PyMuPDF
import faiss
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer

# ------------------ Paths -------------------
PDF_DIR = r"D:\unstop\doc"
EMBEDDINGS_FILE = "embeddings.npy"
CHUNKS_FILE = "chunks.pkl"
INDEX_FILE = "faiss.index"

# ------------------ Load PDFs -------------------
def load_all_pdfs_fast(folder_path):
    all_text = []
    files = os.listdir(folder_path)
    print(f" Found files: {files}")
    for filename in files:
        if filename.lower().endswith(".pdf"):
            full_path = os.path.join(folder_path, filename)
            print(f" Reading: {full_path}")
            doc = fitz.open(full_path)
            text = ""
            for page in doc:
                text += page.get_text()
            all_text.append(text)
    return all_text

# ------------------ Chunk Text -------------------
def chunk_text(text, chunk_size=300, overlap=50):
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size - overlap):
        chunk = words[i:i + chunk_size]
        chunks.append(" ".join(chunk))
    return chunks

# ------------------ Load Model and Index -------------------
print("📥 Loading embedding model...")
model = SentenceTransformer("all-MiniLM-L6-v2")

if os.path.exists(EMBEDDINGS_FILE) and os.path.exists(CHUNKS_FILE) and os.path.exists(INDEX_FILE):
    print("Found saved index and chunks. Loading...")
    embeddings = np.load(EMBEDDINGS_FILE)
    with open(CHUNKS_FILE, "rb") as f:
        all_chunks = pickle.load(f)
    index = faiss.read_index(INDEX_FILE)
else:
    print("📄 Reading and processing PDFs...")
    texts = load_all_pdfs_fast(PDF_DIR)
    all_chunks = []

    for i, doc_text in enumerate(texts):
        print(f"🔧 Chunking Document {i+1}...")
        chunks = chunk_text(doc_text, chunk_size=300, overlap=50)
        print(f"✅ Document {i+1} split into {len(chunks)} chunks.")
        all_chunks.extend(chunks)

    print(f"\n📦 Total chunks ready for embedding: {len(all_chunks)}")
    print("🔍 Encoding all chunks...")

    embeddings = model.encode(all_chunks, show_progress_bar=True)
    np.save(EMBEDDINGS_FILE, embeddings)
    with open(CHUNKS_FILE, "wb") as f:
        pickle.dump(all_chunks, f)

    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    faiss.write_index(index, INDEX_FILE)
    print("✅ Embeddings indexed and saved.")

# ------------------ Query Function -------------------
def get_response(user_query):
    query_embedding = model.encode([user_query])
    D, I = index.search(np.array(query_embedding), k=3)

    best_score = D[0][0]
    best_chunk = all_chunks[I[0][0]]
    threshold = 0.65  # Smaller = stricter matching

    if best_score < threshold:
        response = f"✅ Yes, based on the policy:\n{best_chunk[:300]}..."
    else:
        response = "❌ Sorry, your request does not appear to be covered based on the policy."

    return response, float(best_score)

# ------------------ Terminal Test (Optional) -------------------
if __name__ == "__main__":
    while True:
        user_query = input("\n❓ Enter your insurance query:\n> ").strip()
        if not user_query:
            print("⚠️  Empty query. Please try again.")
            continue

        response, score = get_response(user_query)

        print(f"\n🔍 Match Score: {score:.2f}")
        print(response)

        again = input("\n🔁 Do you want to ask another query? (yes/no): ").strip().lower()
        if again != "yes":
            print("👋 Task ended. Thank you!")
            break
