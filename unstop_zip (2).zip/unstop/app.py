from flask import Flask, render_template, request
from mainfile import get_response  # use the actual function name from your mainfile.py

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    response = ''
    match_score = 0
    if request.method == 'POST':
        query = request.form['query']
        response, match_score = get_response(query)  # or however your function works
    return render_template('index.html', response=response, match_score=match_score)

if __name__ == '__main__':
    app.run(debug=True)
